# Clock

This is a guided project starter for the module _Animation II - Advanced Drawing_ in the sprint _iOS User Interface_.

Begin by forking it to your own GitHub account, then cloning it to your local machine.
